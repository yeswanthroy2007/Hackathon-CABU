
import React from 'react';
import { User, Star, ThumbsUp } from 'lucide-react';
import { Badge } from "@/components/ui/badge";

interface UserCardProps {
  id: string;
  name: string;
  enrollmentNo: string;
  gender: 'male' | 'female' | 'other';
  department?: string;
  rating?: number;
  ridesCompleted?: number;
  image?: string;
}

const UserCard: React.FC<UserCardProps> = ({
  id,
  name,
  enrollmentNo,
  gender,
  department,
  rating = 0,
  ridesCompleted = 0,
  image
}) => {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-shadow duration-300 p-4">
      <div className="flex items-start">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
          gender === 'female' ? 'bg-pink-100 text-pink-600' : 'bg-blue-100 text-blue-600'
        }`}>
          {image ? (
            <img src={image} alt={name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <User className="h-8 w-8" />
          )}
        </div>
        
        <div className="ml-4 flex-1">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-medium text-gray-900">{name}</h3>
              <p className="text-sm text-gray-500">Enrollment: {enrollmentNo}</p>
            </div>
            
            <Badge className={`${
              gender === 'female' ? 'bg-pink-100 text-pink-600' : 
              gender === 'male' ? 'bg-blue-100 text-blue-600' : 'bg-purple-100 text-purple-600'
            } border-0`}>
              {gender.charAt(0).toUpperCase() + gender.slice(1)}
            </Badge>
          </div>
          
          {department && (
            <p className="text-sm text-gray-600 mt-1">Department: {department}</p>
          )}
          
          <div className="flex items-center mt-3 space-x-4">
            <div className="flex items-center">
              <Star className="h-4 w-4 text-amber-500 mr-1" />
              <span className="text-sm text-gray-700">{rating.toFixed(1)}</span>
            </div>
            
            <div className="flex items-center">
              <ThumbsUp className="h-4 w-4 text-eco-600 mr-1" />
              <span className="text-sm text-gray-700">{ridesCompleted} rides</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserCard;
