
import React from 'react';
import { Car, Calendar, Clock, MapPin, Users } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';

export interface RideCardProps {
  id: string;
  from: string;
  to: string;
  date: string;
  time: string;
  seats: number;
  availableSeats: number;
  driver: {
    name: string;
    id: string;
    gender: 'male' | 'female' | 'other';
    enrollmentNo: string;
    image?: string;
  };
  price: number;
  onJoin?: (id: string) => void;
  detailed?: boolean;
}

const RideCard: React.FC<RideCardProps> = ({
  id,
  from,
  to,
  date,
  time,
  seats,
  availableSeats,
  driver,
  price,
  onJoin,
  detailed = false
}) => {
  const handleJoinClick = () => {
    if (onJoin) {
      onJoin(id);
      toast.success("Request sent to join the ride!");
    }
  };

  return (
    <div className={`bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 hover:shadow-lg transition-all duration-300 ${detailed ? 'p-6' : 'p-4'} hover-lift`}>
      <div className="flex items-center justify-between mb-4 animate-fade-in">
        <div className="flex items-center">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${driver.gender === 'female' ? 'bg-pink-100 text-pink-600' : 'bg-blue-100 text-blue-600'}`}>
            {driver.image ? (
              <img src={driver.image} alt={driver.name} className="w-full h-full rounded-full object-cover" />
            ) : (
              driver.name.charAt(0).toUpperCase()
            )}
          </div>
          <div className="ml-3">
            <p className="font-medium text-gray-900">{driver.name}</p>
            <p className="text-xs text-gray-500">Enrollment: {driver.enrollmentNo}</p>
          </div>
        </div>
        <Badge className={`${
          availableSeats === 0 ? 'bg-red-100 text-red-700' :
          availableSeats <= 1 ? 'bg-amber-100 text-amber-700' : 'bg-eco-100 text-eco-700'
        } border-0 animate-pulse-in`}>
          {availableSeats} seat{availableSeats !== 1 ? 's' : ''} left
        </Badge>
      </div>

      <div className="space-y-3 animate-fade-in" style={{ animationDelay: '0.1s' }}>
        <div className="flex items-center">
          <MapPin className="h-4 w-4 text-gray-500 mr-2 flex-shrink-0" />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium">{from}</span>
              <span className="text-xs px-1">{' → '}</span>
              <span className="text-sm font-medium">{to}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm text-gray-700">{date}</span>
          </div>
          <div className="flex items-center">
            <Clock className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm text-gray-700">{time}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Users className="h-4 w-4 text-gray-500 mr-2" />
            <span className="text-sm text-gray-700">{seats} total seats</span>
          </div>
          <div className="font-medium text-eco-700">₹{price}/person</div>
        </div>
      </div>

      {detailed && (
        <div className="mt-4 pt-4 border-t border-gray-100 animate-fade-in" style={{ animationDelay: '0.2s' }}>
          <h4 className="font-medium text-gray-900 mb-2">About this ride</h4>
          <p className="text-sm text-gray-600">
            This is a shared ride from {from} to {to}. The driver will pick you up at the specified location.
            Please be on time and ready 5 minutes before the scheduled departure.
          </p>
        </div>
      )}

      {onJoin && availableSeats > 0 && (
        <div className="mt-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
          <Button 
            onClick={handleJoinClick} 
            className="w-full bg-eco-600 hover:bg-eco-700 text-white hover-scale"
          >
            Request to Join
          </Button>
        </div>
      )}
    </div>
  );
};

export default RideCard;
