
import React from 'react';
import { Link } from 'react-router-dom';
import { Car, Github, Twitter, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-white border-t border-gray-200 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center">
              <Car className="h-6 w-6 text-eco-600" />
              <span className="ml-2 text-lg font-bold bg-gradient-to-r from-eco-600 to-rider-600 bg-clip-text text-transparent">
                Cab U
              </span>
            </div>
            <p className="mt-4 text-sm text-gray-600 max-w-xs">
              Campus ride-sharing platform helping students save money and find convenient transportation.
            </p>
            <div className="flex mt-6 space-x-4">
              <a href="#" className="text-gray-500 hover:text-eco-600">
                <Github className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-eco-600">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-500 hover:text-eco-600">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wide uppercase">
              Navigation
            </h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/" className="text-sm text-gray-600 hover:text-eco-600">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/request" className="text-sm text-gray-600 hover:text-eco-600">
                  Request Ride
                </Link>
              </li>
              <li>
                <Link to="/browse" className="text-sm text-gray-600 hover:text-eco-600">
                  Browse Rides
                </Link>
              </li>
              <li>
                <Link to="/history" className="text-sm text-gray-600 hover:text-eco-600">
                  Ride History
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wide uppercase">
              Resources
            </h3>
            <ul className="mt-4 space-y-2">
              <li>
                <Link to="/safety" className="text-sm text-gray-600 hover:text-eco-600">
                  Safety Tips
                </Link>
              </li>
              <li>
                <Link to="/faq" className="text-sm text-gray-600 hover:text-eco-600">
                  FAQ
                </Link>
              </li>
              <li>
                <Link to="/testimonials" className="text-sm text-gray-600 hover:text-eco-600">
                  Testimonials
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-sm text-gray-600 hover:text-eco-600">
                  About Us
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 tracking-wide uppercase">
              Legal
            </h3>
            <ul className="mt-4 space-y-2">
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-eco-600">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-eco-600">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-sm text-gray-600 hover:text-eco-600">
                  Cookie Policy
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 border-t border-gray-200 pt-6 flex flex-col items-center">
          <p className="text-sm text-gray-600">
            &copy; {new Date().getFullYear()} Cab U. All rights reserved.
          </p>
          <p className="text-xs text-gray-500 mt-2">
            Made with ❤️ for campus students
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
