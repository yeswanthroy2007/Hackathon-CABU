
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Car, User, ClipboardList, MessageSquare, Menu, X, ShieldCheck, HelpCircle, Users, Info } from 'lucide-react';
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navLinks = [
    { name: 'Home', path: '/', icon: null },
    { name: 'Request Ride', path: '/request', icon: <Car className="w-4 h-4 mr-2" /> },
    { name: 'Browse Rides', path: '/browse', icon: <ClipboardList className="w-4 h-4 mr-2" /> },
    { name: 'Messages', path: '/messages', icon: <MessageSquare className="w-4 h-4 mr-2" /> },
    { name: 'Ride History', path: '/history', icon: <ClipboardList className="w-4 h-4 mr-2" /> },
    { name: 'Safety', path: '/safety', icon: <ShieldCheck className="w-4 h-4 mr-2" /> },
    { name: 'FAQ', path: '/faq', icon: <HelpCircle className="w-4 h-4 mr-2" /> },
  ];

  return (
    <nav className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex items-center">
              <img src="/logo.png" alt="University Logo" className="h-10 w-auto hover-scale" />
              <span className="ml-2 text-xl font-bold bg-gradient-to-r from-eco-600 to-rider-600 bg-clip-text text-transparent">
                Cab U
              </span>
            </Link>
          </div>

          {/* Desktop nav */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`flex items-center ${
                  isActive(link.path) ? 'nav-item active' : 'nav-item'
                } hover-scale`}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
            
            <Link to="/profile">
              <Button variant="outline" size="icon" className="ml-4 rounded-full border-eco-200 hover:bg-eco-50 hover-scale">
                <User className="h-5 w-5 text-eco-700" />
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle menu"
              className="hover-scale"
            >
              {isOpen ? (
                <X className="h-6 w-6 text-gray-600" />
              ) : (
                <Menu className="h-6 w-6 text-gray-600" />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white shadow-lg rounded-b-lg animate-fade-in">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {navLinks.map((link, index) => (
              <Link
                key={link.name}
                to={link.path}
                className={`flex items-center px-3 py-2 rounded-md text-base font-medium ${
                  isActive(link.path)
                    ? 'bg-eco-100 text-eco-700'
                    : 'text-gray-700 hover:bg-eco-50 hover:text-eco-600'
                } animate-slide-in-left`}
                style={{ animationDelay: `${index * 0.05}s` }}
                onClick={() => setIsOpen(false)}
              >
                {link.icon}
                {link.name}
              </Link>
            ))}
            <Link
              to="/profile"
              className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-eco-50 hover:text-eco-600 animate-slide-in-left"
              style={{ animationDelay: '0.35s' }}
              onClick={() => setIsOpen(false)}
            >
              <User className="w-4 h-4 mr-2" />
              Profile
            </Link>
            <Link
              to="/testimonials"
              className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-eco-50 hover:text-eco-600 animate-slide-in-left"
              style={{ animationDelay: '0.4s' }}
              onClick={() => setIsOpen(false)}
            >
              <Users className="w-4 h-4 mr-2" />
              Testimonials
            </Link>
            <Link
              to="/about"
              className="flex items-center px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:bg-eco-50 hover:text-eco-600 animate-slide-in-left"
              style={{ animationDelay: '0.45s' }}
              onClick={() => setIsOpen(false)}
            >
              <Info className="w-4 h-4 mr-2" />
              About Us
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
