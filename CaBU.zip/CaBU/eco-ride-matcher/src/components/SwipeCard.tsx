
import React, { useState, useRef } from 'react';
import { RideCardProps } from './RideCard';
import { X, Check, User, MapPin, Calendar, Clock, Users } from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from 'sonner';

interface SwipeCardProps {
  ride: RideCardProps;
  onSwipe: (id: string, direction: 'left' | 'right') => void;
  isActive: boolean;
}

const SwipeCard: React.FC<SwipeCardProps> = ({ ride, onSwipe, isActive }) => {
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const startX = useRef<number>(0);
  const currentX = useRef<number>(0);

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isActive) return;
    startX.current = e.touches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isActive) return;
    currentX.current = e.touches[0].clientX;
    const diff = currentX.current - startX.current;
    
    if (Math.abs(diff) < 20) return;
    
    if (cardRef.current) {
      cardRef.current.style.transform = `translateX(${diff}px) rotate(${diff * 0.05}deg)`;
    }
  };

  const handleTouchEnd = () => {
    if (!isActive) return;
    const diff = currentX.current - startX.current;
    
    if (Math.abs(diff) < 100) {
      // Reset position if not swiped enough
      if (cardRef.current) {
        cardRef.current.style.transform = '';
      }
      return;
    }
    
    if (diff > 0) {
      handleSwipe('right');
    } else {
      handleSwipe('left');
    }
  };

  const handleSwipe = (direction: 'left' | 'right') => {
    setSwipeDirection(direction);
    
    setTimeout(() => {
      onSwipe(ride.id, direction);
      setSwipeDirection(null);
    }, 300);
    
    if (direction === 'right') {
      toast.success("Ride request sent!");
    }
  };

  const genderIndicatorClass = ride.driver.gender === 'female' 
    ? 'bg-pink-100 text-pink-600 border-pink-200' 
    : 'bg-blue-100 text-blue-600 border-blue-200';

  return (
    <div 
      ref={cardRef}
      className={`swipe-card absolute top-0 left-0 right-0 ${isActive ? 'active z-10' : 'z-0'} ${
        swipeDirection === 'left' ? 'animate-card-swipe-left' : 
        swipeDirection === 'right' ? 'animate-card-swipe-right' : ''
      }`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center border-2 ${genderIndicatorClass}`}>
              {ride.driver.image ? (
                <img src={ride.driver.image} alt={ride.driver.name} className="w-full h-full rounded-full object-cover" />
              ) : (
                <User className="h-6 w-6" />
              )}
            </div>
            <div className="ml-3">
              <p className="font-medium text-gray-900">{ride.driver.name}</p>
              <div className="flex items-center">
                <Badge variant="outline" className={`text-xs ${genderIndicatorClass}`}>
                  {ride.driver.gender.charAt(0).toUpperCase() + ride.driver.gender.slice(1)}
                </Badge>
                <span className="mx-2 text-gray-400">•</span>
                <span className="text-xs text-gray-500">{ride.driver.enrollmentNo}</span>
              </div>
            </div>
          </div>
          <Badge className={`${
            ride.availableSeats === 0 ? 'bg-red-100 text-red-700' :
            ride.availableSeats <= 1 ? 'bg-amber-100 text-amber-700' : 'bg-eco-100 text-eco-700'
          } border-0`}>
            {ride.availableSeats} seat{ride.availableSeats !== 1 ? 's' : ''} left
          </Badge>
        </div>

        <div className="space-y-4 mt-6">
          <div className="flex items-start">
            <MapPin className="h-5 w-5 text-eco-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-gray-500">Route</p>
              <div className="flex items-center mt-1">
                <span className="font-medium">{ride.from}</span>
                <span className="mx-2 text-gray-400">→</span>
                <span className="font-medium">{ride.to}</span>
              </div>
            </div>
          </div>

          <div className="flex items-start">
            <Calendar className="h-5 w-5 text-eco-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-gray-500">Date</p>
              <p className="font-medium mt-1">{ride.date}</p>
            </div>
          </div>

          <div className="flex items-start">
            <Clock className="h-5 w-5 text-eco-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-gray-500">Time</p>
              <p className="font-medium mt-1">{ride.time}</p>
            </div>
          </div>

          <div className="flex items-start">
            <Users className="h-5 w-5 text-eco-600 mr-3 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-gray-500">Total Seats</p>
              <p className="font-medium mt-1">{ride.seats}</p>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-gray-100">
          <div className="flex justify-between items-center">
            <span className="text-sm text-gray-500">Price per person</span>
            <span className="font-bold text-xl text-eco-700">₹{ride.price}</span>
          </div>
        </div>
      </div>

      <div className="swipe-actions mx-auto pb-6">
        <Button 
          onClick={() => handleSwipe('left')} 
          variant="outline"
          size="icon"
          className="swipe-button swipe-button-reject h-14 w-14"
        >
          <X className="h-6 w-6" />
        </Button>
        <Button
          onClick={() => handleSwipe('right')}
          variant="outline"
          size="icon"
          className="swipe-button swipe-button-accept h-14 w-14"
        >
          <Check className="h-6 w-6" />
        </Button>
      </div>
    </div>
  );
};

export default SwipeCard;
