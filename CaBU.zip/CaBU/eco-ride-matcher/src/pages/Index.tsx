
import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Car, Users, Tag, ThumbsUp, ArrowRight, Clock, Wallet, Shield, BookOpen, Coffee, Award, MapPin, CalendarClock, Smartphone } from 'lucide-react';
import { Button } from "@/components/ui/button";
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const Index = () => {
  // References for animation elements
  const heroRef = useRef<HTMLDivElement>(null);
  const benefitsRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);

  // Animate elements when they come into view
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate-fade-in');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1 });

    const elements = document.querySelectorAll('.animate-on-scroll');
    elements.forEach(el => observer.observe(el));

    return () => elements.forEach(el => observer.unobserve(el));
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section ref={heroRef} className="bg-gradient-to-r from-eco-50 to-rider-50 py-16 md:py-24 overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-8 items-center">
              <div className="mb-12 lg:mb-0 animate-slide-in-left">
                <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight">
                  Share Rides, <span className="text-eco-600">Save Money</span>, Travel Together
                </h1>
                <p className="mt-4 text-lg text-gray-600 max-w-lg">
                  Connect with fellow students going the same way. Cab U makes it easy to share rides, split costs, and travel safely around campus.
                </p>
                <div className="mt-8 flex flex-wrap gap-4">
                  <Link to="/request">
                    <Button className="bg-eco-600 hover:bg-eco-700 text-white hover-scale">
                      Request a Ride
                    </Button>
                  </Link>
                  <Link to="/browse">
                    <Button variant="outline" className="border-eco-600 text-eco-600 hover:bg-eco-50 hover-scale">
                      Browse Available Rides
                    </Button>
                  </Link>
                </div>
                <div className="mt-10 flex items-center space-x-6 animate-bounce-in" style={{ animationDelay: '0.3s' }}>
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <Users className="h-5 w-5 text-eco-600" />
                    </div>
                    <p className="ml-3 text-sm text-gray-600">
                      <span className="font-bold text-gray-900">1200+</span> Active Riders
                    </p>
                  </div>
                  <div className="flex items-center">
                    <div className="h-10 w-10 rounded-full bg-white flex items-center justify-center shadow-sm">
                      <Tag className="h-5 w-5 text-eco-600" />
                    </div>
                    <p className="ml-3 text-sm text-gray-600">
                      <span className="font-bold text-gray-900">30%</span> Average Savings
                    </p>
                  </div>
                </div>
              </div>
              <div className="relative animate-slide-in-right">
                <div className="bg-white p-1 rounded-2xl shadow-lg w-full max-w-md mx-auto hover-lift">
                  <img
                    src="https://images.unsplash.com/photo-1532771400976-e0d858f91995?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Students sharing a ride"
                    className="rounded-xl object-cover w-full aspect-[4/3]"
                  />
                </div>
                <div className="absolute -bottom-6 -left-6 bg-white rounded-lg shadow-md p-3 animate-float">
                  <div className="flex items-center">
                    <Car className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium">30+ Rides Today</span>
                  </div>
                </div>
                <div className="absolute -top-6 -right-6 bg-white rounded-lg shadow-md p-3 animate-float" style={{ animationDelay: '1s' }}>
                  <div className="flex items-center">
                    <ThumbsUp className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium">98% Happy Users</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section - NEW */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-on-scroll">
              <h2 className="text-3xl font-bold text-gray-900">Campus Life Made Easier</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                All the features you need for hassle-free commuting
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="feature-card hover-lift animate-on-scroll">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Smartphone className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Mobile App</h3>
                <p className="text-gray-600">
                  Easy access to ride-sharing on your phone with real-time updates and notifications
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.1s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <CalendarClock className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Schedule Ahead</h3>
                <p className="text-gray-600">
                  Plan your rides in advance for classes, events and weekend trips
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.2s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <MapPin className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Multiple Locations</h3>
                <p className="text-gray-600">
                  Get rides to all campus buildings, dorms, shopping areas and popular spots
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.3s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Award className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Rewards Program</h3>
                <p className="text-gray-600">
                  Earn points for each ride you share and redeem them for campus perks
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section ref={benefitsRef} className="py-16 bg-eco-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-on-scroll">
              <h2 className="text-3xl font-bold text-gray-900">Student Benefits</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                Why students across campus choose Cab U for their daily commute
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="feature-card hover-lift animate-on-scroll">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Wallet className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Save Money</h3>
                <p className="text-gray-600">
                  Split ride costs with fellow students and save up to 70% on your regular transportation expenses.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.1s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Save Time</h3>
                <p className="text-gray-600">
                  No waiting for public transport or walking long distances. Get direct rides to your destination.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.2s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Shield className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Stay Safe</h3>
                <p className="text-gray-600">
                  Ride only with verified university students. Student ID verification keeps our community safe.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Academic Benefits - NEW */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-on-scroll">
              <h2 className="text-3xl font-bold text-gray-900">Academic Advantages</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                How Cab U helps you succeed in your studies
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="feature-card hover-lift animate-on-scroll">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <BookOpen className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Never Miss Class</h3>
                <p className="text-gray-600">
                  Reliable transportation ensures you're always on time for lectures, even during bad weather.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.1s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Coffee className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Study Groups</h3>
                <p className="text-gray-600">
                  Connect with classmates for study sessions and build a network with students from your course.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.2s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <Clock className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Optimize Schedule</h3>
                <p className="text-gray-600">
                  Spend less time commuting and more time studying, with efficient ride coordination.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section ref={featuresRef} className="py-16 bg-eco-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-on-scroll">
              <h2 className="text-3xl font-bold text-gray-900">How It Works</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                Cab U makes ride-sharing simple and efficient for campus students
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="feature-card hover-lift animate-on-scroll">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <span className="text-eco-600 font-bold text-xl">1</span>
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Request or Offer</h3>
                <p className="text-gray-600">
                  Need a ride or have empty seats? Create a ride request or offer in seconds.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.1s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <span className="text-eco-600 font-bold text-xl">2</span>
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Match & Connect</h3>
                <p className="text-gray-600">
                  Our smart matching shows you compatible rides. Swipe right to connect.
                </p>
              </div>
              
              <div className="feature-card hover-lift animate-on-scroll" style={{ animationDelay: '0.2s' }}>
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mb-4">
                  <span className="text-eco-600 font-bold text-xl">3</span>
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Ride & Save</h3>
                <p className="text-gray-600">
                  Meet at the pickup point, share the ride, split the cost, and enjoy the journey.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12 animate-on-scroll">
              <h2 className="text-3xl font-bold text-gray-900">Making Campus Life Better</h2>
              <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
                Join the campus movement towards affordable and convenient transportation
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="stats-card hover-lift animate-on-scroll">
                <span className="text-3xl font-bold text-eco-600">5,280+</span>
                <span className="text-gray-600 mt-2">Rides Shared</span>
              </div>
              
              <div className="stats-card hover-lift animate-on-scroll" style={{ animationDelay: '0.1s' }}>
                <span className="text-3xl font-bold text-eco-600">₹2.1M+</span>
                <span className="text-gray-600 mt-2">Money Saved</span>
              </div>
              
              <div className="stats-card hover-lift animate-on-scroll" style={{ animationDelay: '0.2s' }}>
                <span className="text-3xl font-bold text-eco-600">15+</span>
                <span className="text-gray-600 mt-2">Campus Locations</span>
              </div>
              
              <div className="stats-card hover-lift animate-on-scroll" style={{ animationDelay: '0.3s' }}>
                <span className="text-3xl font-bold text-eco-600">1,200+</span>
                <span className="text-gray-600 mt-2">Active Users</span>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-eco-600 to-rider-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-6 animate-on-scroll">Ready to start saving?</h2>
            <p className="text-xl text-white opacity-90 mb-8 max-w-2xl mx-auto animate-on-scroll">
              Join your fellow students in making travel more affordable and convenient
            </p>
            <Link to="/request">
              <Button variant="secondary" size="lg" className="bg-white text-eco-700 hover:bg-gray-100 hover-scale animate-bounce-in">
                Get Started <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
