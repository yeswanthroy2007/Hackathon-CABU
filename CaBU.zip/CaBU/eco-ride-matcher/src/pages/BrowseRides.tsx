
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, Filter, SearchX } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import SwipeCard from '@/components/SwipeCard';
import EmptyState from '@/components/EmptyState';
import { RideCardProps } from '@/components/RideCard';

// Sample data for demo
const sampleRides: RideCardProps[] = [
  {
    id: '1',
    from: 'University Main Gate',
    to: 'City Center Mall',
    date: '2025-04-07',
    time: '14:30',
    seats: 4,
    availableSeats: 3,
    driver: {
      name: 'Rahul Sharma',
      id: 'u1',
      gender: 'male',
      enrollmentNo: 'EN2023001',
    },
    price: 50,
  },
  {
    id: '2',
    from: 'Library',
    to: 'Railway Station',
    date: '2025-04-07',
    time: '16:15',
    seats: 3,
    availableSeats: 1,
    driver: {
      name: 'Priya Singh',
      id: 'u2',
      gender: 'female',
      enrollmentNo: 'EN2022089',
    },
    price: 70,
  },
  {
    id: '3',
    from: 'North Campus',
    to: 'Airport',
    date: '2025-04-08',
    time: '09:00',
    seats: 4,
    availableSeats: 2,
    driver: {
      name: 'Amit Kumar',
      id: 'u3',
      gender: 'male',
      enrollmentNo: 'EN2021145',
    },
    price: 120,
  },
  {
    id: '4',
    from: 'Sports Complex',
    to: 'University Main Gate',
    date: '2025-04-08',
    time: '18:30',
    seats: 2,
    availableSeats: 2,
    driver: {
      name: 'Neha Patel',
      id: 'u4',
      gender: 'female',
      enrollmentNo: 'EN2022056',
    },
    price: 40,
  },
];

const BrowseRides = () => {
  const navigate = useNavigate();
  const [rides, setRides] = useState<RideCardProps[]>([]);
  const [filteredRides, setFilteredRides] = useState<RideCardProps[]>([]);
  const [currentRideIndex, setCurrentRideIndex] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    from: '',
    to: '',
    date: '',
    gender: '',
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setRides(sampleRides);
      setFilteredRides(sampleRides);
      setIsLoading(false);
    }, 1000);
  }, []);

  const handleSwipe = (id: string, direction: 'left' | 'right') => {
    console.log(`Swiped ${direction} on ride ${id}`);
    
    if (direction === 'right') {
      // Send join request
      console.log(`Sending join request for ride ${id}`);
    }
    
    // Move to next card
    setTimeout(() => {
      setCurrentRideIndex(prev => {
        if (prev < filteredRides.length - 1) {
          return prev + 1;
        } else {
          // No more rides to show
          return prev;
        }
      });
    }, 300);
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const applyFilters = () => {
    let filtered = [...rides];
    
    if (filters.from) {
      filtered = filtered.filter(ride => 
        ride.from.toLowerCase().includes(filters.from.toLowerCase())
      );
    }
    
    if (filters.to) {
      filtered = filtered.filter(ride => 
        ride.to.toLowerCase().includes(filters.to.toLowerCase())
      );
    }
    
    if (filters.date) {
      filtered = filtered.filter(ride => ride.date === filters.date);
    }
    
    if (filters.gender) {
      filtered = filtered.filter(ride => 
        ride.driver.gender === filters.gender
      );
    }
    
    setFilteredRides(filtered);
    setCurrentRideIndex(0);
    setShowFilters(false);
    
    toast.success(`Found ${filtered.length} rides matching your filters!`);
  };

  const resetFilters = () => {
    setFilters({
      from: '',
      to: '',
      date: '',
      gender: '',
    });
    setFilteredRides(rides);
    setCurrentRideIndex(0);
    toast.info("Filters have been reset");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-grow flex items-center justify-center">
          <div className="animate-pulse-eco h-16 w-16 rounded-full bg-eco-100 flex items-center justify-center">
            <Car className="h-8 w-8 text-eco-600" />
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="max-w-lg mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Browse Rides</h1>
              <p className="text-gray-600 mt-1">
                Swipe right to join, left to skip
              </p>
            </div>
            
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => setShowFilters(!showFilters)}
            >
              <Filter className="h-4 w-4" />
              Filter
            </Button>
          </div>
          
          {showFilters && (
            <div className="bg-white rounded-xl shadow-md p-6 mb-8 border border-gray-100 animate-fade-in">
              <h3 className="font-medium text-gray-900 mb-4">Filter Rides</h3>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="from-filter">From</Label>
                  <Input 
                    id="from-filter"
                    placeholder="Pickup location"
                    value={filters.from}
                    onChange={(e) => handleFilterChange('from', e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="to-filter">To</Label>
                  <Input 
                    id="to-filter"
                    placeholder="Destination"
                    value={filters.to}
                    onChange={(e) => handleFilterChange('to', e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="date-filter">Date</Label>
                  <Input 
                    id="date-filter"
                    type="date"
                    value={filters.date}
                    onChange={(e) => handleFilterChange('date', e.target.value)}
                  />
                </div>
                
                <div>
                  <Label htmlFor="gender-filter">Driver Gender</Label>
                  <Select 
                    value={filters.gender} 
                    onValueChange={(value) => handleFilterChange('gender', value)}
                  >
                    <SelectTrigger id="gender-filter">
                      <SelectValue placeholder="Any gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">Any gender</SelectItem>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center space-x-3 pt-2">
                  <Button 
                    onClick={applyFilters}
                    className="flex-1 bg-eco-600 hover:bg-eco-700 text-white"
                  >
                    Apply Filters
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={resetFilters}
                    className="flex-1"
                  >
                    Reset
                  </Button>
                </div>
              </div>
            </div>
          )}
          
          <div className="relative h-[500px] mb-8">
            {filteredRides.length > 0 ? (
              filteredRides.map((ride, index) => (
                <SwipeCard 
                  key={ride.id}
                  ride={ride}
                  onSwipe={handleSwipe}
                  isActive={index === currentRideIndex}
                />
              ))
            ) : (
              <EmptyState 
                title="No rides found"
                description="Try changing your filters or create a new ride request"
                icon={<SearchX className="h-8 w-8" />}
                actionLabel="Create Ride Request"
                actionLink="/request"
              />
            )}
            
            {filteredRides.length > 0 && currentRideIndex >= filteredRides.length && (
              <div className="absolute inset-0 flex items-center justify-center">
                <EmptyState 
                  title="No more rides"
                  description="You've seen all available rides matching your criteria"
                  icon={<Car className="h-8 w-8" />}
                  actionLabel="Create Ride Request"
                  actionLink="/request"
                />
              </div>
            )}
          </div>
          
          <div className="flex justify-center">
            <Button
              onClick={() => navigate('/request')}
              className="bg-eco-600 hover:bg-eco-700 text-white"
            >
              Create Your Own Ride Request
              <Car className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default BrowseRides;
