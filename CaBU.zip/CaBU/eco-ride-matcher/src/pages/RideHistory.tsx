
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, Search, Clock, CarFront, Map } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import RideCard from '@/components/RideCard';
import EmptyState from '@/components/EmptyState';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

// Sample ride history data
const pastRides = [
  {
    id: 'past1',
    from: 'University Main Gate',
    to: 'City Center Mall',
    date: '2025-04-03',
    time: '14:30',
    seats: 4,
    availableSeats: 0,
    driver: {
      name: 'Rahul Sharma',
      id: 'u1',
      gender: 'male' as 'male',
      enrollmentNo: 'EN2023001',
    },
    price: 50,
    status: 'completed',
  },
  {
    id: 'past2',
    from: 'Railway Station',
    to: 'University Main Gate',
    date: '2025-04-01',
    time: '09:15',
    seats: 3,
    availableSeats: 0,
    driver: {
      name: 'Priya Singh',
      id: 'u2',
      gender: 'female' as 'female',
      enrollmentNo: 'EN2022089',
    },
    price: 70,
    status: 'completed',
  },
];

const upcomingRides = [
  {
    id: 'up1',
    from: 'North Campus',
    to: 'Airport',
    date: '2025-04-10',
    time: '09:00',
    seats: 4,
    availableSeats: 2,
    driver: {
      name: 'Amit Kumar',
      id: 'u3',
      gender: 'male' as 'male',
      enrollmentNo: 'EN2021145',
    },
    price: 120,
    status: 'upcoming',
  },
];

const cancelledRides = [
  {
    id: 'cancel1',
    from: 'Sports Complex',
    to: 'City Center Mall',
    date: '2025-03-28',
    time: '16:30',
    seats: 2,
    availableSeats: 0,
    driver: {
      name: 'Neha Patel',
      id: 'u4',
      gender: 'female' as 'female',
      enrollmentNo: 'EN2022056',
    },
    price: 60,
    status: 'cancelled',
    reason: 'Driver cancelled the ride',
  },
];

const RideHistory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPastRides = pastRides.filter(ride =>
    ride.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.driver.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredUpcomingRides = upcomingRides.filter(ride =>
    ride.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.driver.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredCancelledRides = cancelledRides.filter(ride =>
    ride.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
    ride.driver.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Your Ride History</h1>
            <p className="text-gray-600 mt-2">
              View and manage all your past, upcoming, and cancelled rides
            </p>
          </div>
          
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search rides by location or driver name..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <Tabs defaultValue="upcoming">
            <TabsList className="mb-6">
              <TabsTrigger value="upcoming" className="flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                Upcoming ({filteredUpcomingRides.length})
              </TabsTrigger>
              <TabsTrigger value="past" className="flex items-center">
                <Clock className="h-4 w-4 mr-2" />
                Past ({filteredPastRides.length})
              </TabsTrigger>
              <TabsTrigger value="cancelled" className="flex items-center">
                <CarFront className="h-4 w-4 mr-2" />
                Cancelled ({filteredCancelledRides.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="upcoming">
              {filteredUpcomingRides.length > 0 ? (
                <div className="space-y-6">
                  {filteredUpcomingRides.map((ride) => (
                    <div key={ride.id} className="relative">
                      <Badge className="absolute top-3 right-3 z-10 bg-eco-100 text-eco-700 border-0">
                        Upcoming
                      </Badge>
                      <RideCard {...ride} detailed />
                      <div className="mt-4 flex space-x-3">
                        <Button className="flex-1 text-red-600 border-red-200 hover:bg-red-50" variant="outline">
                          Cancel Ride
                        </Button>
                        <Button className="flex-1 bg-eco-600 hover:bg-eco-700 text-white">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title="No upcoming rides"
                  description="You don't have any upcoming rides at the moment."
                  icon={<Calendar className="h-8 w-8" />}
                  actionLabel="Find a Ride"
                  actionLink="/browse"
                />
              )}
            </TabsContent>
            
            <TabsContent value="past">
              {filteredPastRides.length > 0 ? (
                <div className="space-y-6">
                  {filteredPastRides.map((ride) => (
                    <div key={ride.id} className="relative">
                      <Badge className="absolute top-3 right-3 z-10 bg-gray-100 text-gray-700 border-0">
                        Completed
                      </Badge>
                      <RideCard {...ride} detailed />
                      <div className="mt-4 flex">
                        <Button className="flex-1 bg-eco-600 hover:bg-eco-700 text-white">
                          Request Similar Ride
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title="No past rides"
                  description="You haven't completed any rides yet."
                  icon={<Clock className="h-8 w-8" />}
                  actionLabel="Find a Ride"
                  actionLink="/browse"
                />
              )}
            </TabsContent>
            
            <TabsContent value="cancelled">
              {filteredCancelledRides.length > 0 ? (
                <div className="space-y-6">
                  {filteredCancelledRides.map((ride) => (
                    <div key={ride.id} className="relative">
                      <Badge className="absolute top-3 right-3 z-10 bg-red-100 text-red-700 border-0">
                        Cancelled
                      </Badge>
                      <RideCard {...ride} detailed />
                      <div className="bg-red-50 border border-red-100 rounded-md p-3 mt-3">
                        <p className="text-sm text-red-700">
                          <span className="font-medium">Cancellation reason:</span> {ride.reason}
                        </p>
                      </div>
                      <div className="mt-4 flex">
                        <Button className="flex-1 bg-eco-600 hover:bg-eco-700 text-white">
                          Request Similar Ride
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title="No cancelled rides"
                  description="You don't have any cancelled rides."
                  icon={<CarFront className="h-8 w-8" />}
                  actionLabel="Find a Ride"
                  actionLink="/browse"
                />
              )}
            </TabsContent>
          </Tabs>
          
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 mt-8">
            <h3 className="font-medium text-blue-800 flex items-center">
              <Map className="h-5 w-5 mr-2" />
              Travel Statistics
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-3">
              <div className="bg-white rounded-md p-3 shadow-sm">
                <div className="text-sm text-gray-500">Total Distance</div>
                <div className="text-xl font-bold text-gray-900">124 km</div>
              </div>
              <div className="bg-white rounded-md p-3 shadow-sm">
                <div className="text-sm text-gray-500">Money Saved</div>
                <div className="text-xl font-bold text-gray-900">₹780</div>
              </div>
              <div className="bg-white rounded-md p-3 shadow-sm">
                <div className="text-sm text-gray-500">CO₂ Reduced</div>
                <div className="text-xl font-bold text-gray-900">32 kg</div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RideHistory;
