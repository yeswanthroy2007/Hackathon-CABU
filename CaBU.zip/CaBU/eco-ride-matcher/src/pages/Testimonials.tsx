
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Star, Quote } from 'lucide-react';

interface TestimonialProps {
  name: string;
  department: string;
  year: string;
  quote: string;
  rating: number;
  image?: string;
}

const TestimonialCard = ({ name, department, year, quote, rating, image }: TestimonialProps) => (
  <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100 hover:shadow-lg transition-all duration-300">
    <div className="flex items-center mb-4">
      <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mr-4">
        {image ? (
          <img src={image} alt={name} className="h-full w-full rounded-full object-cover" />
        ) : (
          <Quote className="h-6 w-6 text-eco-600" />
        )}
      </div>
      <div>
        <h3 className="font-medium text-gray-900">{name}</h3>
        <p className="text-sm text-gray-500">{department}, {year}</p>
      </div>
    </div>
    
    <p className="text-gray-600 italic mb-4">"{quote}"</p>
    
    <div className="flex items-center">
      {Array.from({ length: 5 }).map((_, index) => (
        <Star 
          key={index}
          className={`h-4 w-4 ${index < rating ? 'text-amber-500 fill-amber-500' : 'text-gray-300'}`}
        />
      ))}
    </div>
  </div>
);

const Testimonials = () => {
  const testimonials: TestimonialProps[] = [
    {
      name: "Priya Sharma",
      department: "Computer Science",
      year: "3rd Year",
      quote: "Cab U has been a lifesaver for my daily commute to campus! I save at least ₹2000 every month by sharing rides, and I've made some great friends along the way.",
      rating: 5
    },
    {
      name: "Rahul Mehta",
      department: "Engineering",
      year: "4th Year",
      quote: "As someone who lives far from campus, finding reliable transportation was always a challenge. With Cab U, I can easily find rides that fit my schedule.",
      rating: 4
    },
    {
      name: "Ananya Patel",
      department: "Business Administration",
      year: "2nd Year",
      quote: "I feel much safer using Cab U compared to regular cabs since I know I'm riding with fellow students. The female rider preference option is a great feature!",
      rating: 5
    },
    {
      name: "Vikram Singh",
      department: "Physics",
      year: "3rd Year",
      quote: "I've been offering rides through Cab U for the past semester. It helps cover my fuel costs, and the scheduling is super flexible around my classes.",
      rating: 4
    },
    {
      name: "Neha Gupta",
      department: "Medicine",
      year: "1st Year",
      quote: "Early morning clinical rotations were a transportation nightmare until I found Cab U. Now I can reliably get to the hospital on time without stressing about public transport.",
      rating: 5
    },
    {
      name: "Arjun Kapoor",
      department: "Architecture",
      year: "Final Year",
      quote: "Carrying my project materials on public transport was impossible. Cab U connects me with students who have cars and are willing to help. It's been incredible for my studies.",
      rating: 5
    },
    {
      name: "Meera Reddy",
      department: "Literature",
      year: "2nd Year",
      quote: "The money I save using Cab U goes straight to my books budget! It's made a real difference in my ability to afford course materials.",
      rating: 4
    },
    {
      name: "Karan Malhotra",
      department: "Sports Science",
      year: "3rd Year",
      quote: "Getting to off-campus games and practice sessions is so much easier with Cab U. I connect with teammates and we all ride together.",
      rating: 4
    }
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">What Students Are Saying</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it - hear from fellow students who have transformed their daily commute with Cab U.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard key={index} {...testimonial} />
            ))}
          </div>
          
          <div className="mt-16 bg-gradient-to-r from-eco-600 to-rider-600 rounded-xl p-8 text-white text-center">
            <h2 className="text-2xl font-bold mb-4">Share Your Cab U Experience</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              Have you had a great experience using Cab U? We'd love to hear about it! Share your story and help other students discover the benefits of ride-sharing.
            </p>
            <button className="bg-white text-eco-700 px-6 py-3 rounded-md font-medium hover:bg-gray-100 transition-colors">
              Submit Your Testimonial
            </button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Testimonials;
