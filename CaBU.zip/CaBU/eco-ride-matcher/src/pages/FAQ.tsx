
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ChevronDown } from 'lucide-react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
            <p className="text-lg text-gray-600">
              Everything you need to know about the Cab U platform
            </p>
          </div>
          
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                How do I request a ride?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                To request a ride, log in to your account and click on the "Request a Ride" button. Fill in your pickup location, destination, date, time, and any other relevant details. Once submitted, drivers going the same way can see your request and accept it.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                How is the fare calculated?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Fares are calculated based on distance, estimated fuel consumption, and the number of passengers sharing the ride. The app divides the total cost among all passengers, ensuring everyone pays a fair share.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                Is Cab U only for students?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Yes, Cab U is exclusively for verified students of our university. This ensures safety and builds a trusted community. You'll need to verify your student ID when creating an account.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                What payment methods are accepted?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Cab U currently supports payments through UPI, credit/debit cards, and our in-app wallet. Cash payments are also accepted, but we recommend digital payments for a seamless experience.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                How do I cancel a ride?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                You can cancel a ride from the "My Rides" section in your profile. If you cancel more than 30 minutes before the scheduled pickup time, there's no cancellation fee. Last-minute cancellations may incur a small fee to compensate the driver.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                Is my personal information secure?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Absolutely. We take data security very seriously. Your personal information is encrypted and only shared with ride participants when necessary. We never share your contact details with third parties.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-7">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                Can I schedule rides in advance?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Yes, you can schedule rides up to 7 days in advance. This is particularly useful for regular commutes to classes or for planning weekend trips.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-8">
              <AccordionTrigger className="text-left font-medium text-gray-900">
                What happens if my ride doesn't show up?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                If your ride doesn't arrive within 15 minutes of the scheduled time, you can report it in the app. Our support team will assist you in finding an alternative and you'll receive a credit for your inconvenience.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="mt-12 bg-eco-50 rounded-lg p-6 text-center">
            <h3 className="text-xl font-semibold text-gray-900 mb-3">Still have questions?</h3>
            <p className="text-gray-600 mb-4">Contact our support team and we'll get back to you as soon as possible.</p>
            <button className="bg-eco-600 text-white px-5 py-2 rounded-md hover:bg-eco-700 transition-colors">
              Contact Support
            </button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default FAQ;
