
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { ShieldCheck, UserCheck, Lock, Bell, Phone, Share2, Users, AlertTriangle } from 'lucide-react';

const SafetyTip = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => (
  <div className="bg-white rounded-lg shadow-sm p-6 border border-gray-100">
    <div className="flex items-start">
      <div className="flex-shrink-0 p-2 bg-eco-100 rounded-full">
        {icon}
      </div>
      <div className="ml-4">
        <h3 className="text-lg font-medium text-gray-900">{title}</h3>
        <p className="mt-2 text-gray-600">{description}</p>
      </div>
    </div>
  </div>
);

const Safety = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-12 bg-eco-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Your Safety is Our Priority</h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We've built Cab U with comprehensive safety features to ensure you have a secure and comfortable ride experience every time.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <SafetyTip 
              icon={<UserCheck className="h-6 w-6 text-eco-600" />}
              title="Verified University Students Only"
              description="Every user on Cab U must verify their university student ID. This ensures you're always riding with fellow students."
            />
            
            <SafetyTip 
              icon={<Lock className="h-6 w-6 text-eco-600" />}
              title="Secure Personal Information"
              description="Your contact details are only shared with your matched ride partner after both parties have confirmed the ride."
            />
            
            <SafetyTip 
              icon={<Bell className="h-6 w-6 text-eco-600" />}
              title="Real-time Ride Alerts"
              description="Receive notifications when your ride is on the way, has arrived, and when your ride has been completed."
            />
            
            <SafetyTip 
              icon={<Phone className="h-6 w-6 text-eco-600" />}
              title="Emergency Assistance"
              description="Access our emergency button during your ride to contact campus security or local authorities immediately."
            />
            
            <SafetyTip 
              icon={<Share2 className="h-6 w-6 text-eco-600" />}
              title="Share Your Trip Details"
              description="Easily share your ride status and location with friends or family so they can follow your journey in real-time."
            />
            
            <SafetyTip 
              icon={<Users className="h-6 w-6 text-eco-600" />}
              title="Gender Preference Options"
              description="Female riders can choose to ride only with other female passengers for added comfort and security."
            />
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-8 border border-gray-100">
            <div className="flex flex-col md:flex-row items-start md:items-center">
              <div className="mr-6 mb-4 md:mb-0">
                <ShieldCheck className="h-12 w-12 text-eco-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-3">Our Safety Commitment</h2>
                <p className="text-gray-600 mb-4">
                  At Cab U, we continuously work to improve our safety features and protocols. All users undergo verification, and we maintain a strict code of conduct. Any reports of unsafe behavior are immediately investigated and appropriate action is taken.
                </p>
                <div className="bg-amber-50 border-l-4 border-amber-500 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <AlertTriangle className="h-5 w-5 text-amber-500" />
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-amber-700">
                        Remember, if you ever feel uncomfortable during a ride, you can use the emergency feature in the app or contact campus security directly.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <h3 className="text-xl font-semibold text-gray-900 mb-4">Report a Safety Concern</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              If you've experienced or witnessed any behavior that compromises safety, please report it immediately.
            </p>
            <button className="bg-eco-600 text-white px-6 py-3 rounded-md hover:bg-eco-700 transition-colors">
              Report a Concern
            </button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Safety;
