
import React, { useState } from 'react';
import { MessageSquare, User, Search, Check, X, Info, Filter } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EmptyState from '@/components/EmptyState';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { toast } from 'sonner';

// Sample messages data
const rideRequests = [
  {
    id: 'req1',
    sender: {
      id: 'user1',
      name: 'Priya Singh',
      gender: 'female',
      enrollmentNo: 'EN2022089',
      image: ''
    },
    ride: {
      id: 'ride1',
      from: 'University Main Gate',
      to: 'City Center Mall',
      date: '2025-04-07',
      time: '14:30',
    },
    message: 'Hi, I would like to join your ride to City Center tomorrow!',
    timestamp: '2025-04-06T10:23:00Z',
    status: 'pending'
  },
  {
    id: 'req2',
    sender: {
      id: 'user2',
      name: 'Ravi Kumar',
      gender: 'male',
      enrollmentNo: 'EN2021067',
      image: ''
    },
    ride: {
      id: 'ride2',
      from: 'North Campus',
      to: 'Railway Station',
      date: '2025-04-08',
      time: '09:15',
    },
    message: 'Can I join your ride? I have a small backpack only.',
    timestamp: '2025-04-06T09:10:00Z',
    status: 'pending'
  }
];

const notifications = [
  {
    id: 'notif1',
    title: 'Ride Request Accepted',
    message: 'Your request to join the ride from University to Airport has been accepted.',
    timestamp: '2025-04-05T14:23:00Z',
    isRead: false,
    type: 'success'
  },
  {
    id: 'notif2',
    title: 'New Ride Matches',
    message: 'We found 3 new rides matching your frequent routes.',
    timestamp: '2025-04-04T08:15:00Z',
    isRead: true,
    type: 'info'
  },
  {
    id: 'notif3',
    title: 'Ride Cancelled',
    message: 'Your ride to City Center on April 3rd has been cancelled by the driver.',
    timestamp: '2025-04-02T19:30:00Z',
    isRead: true,
    type: 'error'
  }
];

const Messages = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [allRequests, setAllRequests] = useState(rideRequests);
  const [allNotifications, setAllNotifications] = useState(notifications);
  
  const filteredRequests = allRequests.filter(req =>
    req.sender.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.ride.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
    req.ride.to.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredNotifications = allNotifications.filter(notif =>
    notif.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    notif.message.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleAcceptRequest = (requestId: string) => {
    setAllRequests(prev => 
      prev.map(req => 
        req.id === requestId ? {...req, status: 'accepted'} : req
      )
    );
    toast.success("Ride request accepted!");
  };
  
  const handleRejectRequest = (requestId: string) => {
    setAllRequests(prev => 
      prev.map(req => 
        req.id === requestId ? {...req, status: 'rejected'} : req
      )
    );
    toast.info("Ride request rejected");
  };
  
  const handleMarkAllAsRead = () => {
    setAllNotifications(prev => 
      prev.map(notif => ({...notif, isRead: true}))
    );
    toast.success("All notifications marked as read");
  };
  
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const unreadCount = allNotifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Messages & Notifications</h1>
            <p className="text-gray-600 mt-2">
              Manage your ride requests and stay updated with important notifications
            </p>
          </div>
          
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <Input
                placeholder="Search messages and notifications..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
          
          <Tabs defaultValue="requests">
            <div className="flex items-center justify-between mb-6">
              <TabsList>
                <TabsTrigger value="requests" className="flex items-center">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Ride Requests
                  {filteredRequests.filter(r => r.status === 'pending').length > 0 && (
                    <Badge className="ml-2 bg-eco-500 text-white">
                      {filteredRequests.filter(r => r.status === 'pending').length}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="notifications" className="flex items-center">
                  <Info className="h-4 w-4 mr-2" />
                  Notifications
                  {unreadCount > 0 && (
                    <Badge className="ml-2 bg-eco-500 text-white">
                      {unreadCount}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="flex items-center gap-2"
                onClick={handleMarkAllAsRead}
              >
                <Filter className="h-4 w-4" />
                Mark All as Read
              </Button>
            </div>
            
            <TabsContent value="requests">
              {filteredRequests.length > 0 ? (
                <div className="space-y-4">
                  {filteredRequests.map((request) => (
                    <div key={request.id} className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                      <div className="p-4">
                        <div className="flex items-start">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                            request.sender.gender === 'female' ? 'bg-pink-100 text-pink-600' : 'bg-blue-100 text-blue-600'
                          }`}>
                            {request.sender.image ? (
                              <img 
                                src={request.sender.image} 
                                alt={request.sender.name} 
                                className="w-full h-full rounded-full object-cover" 
                              />
                            ) : (
                              <User className="h-6 w-6" />
                            )}
                          </div>
                          
                          <div className="ml-3 flex-1">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-gray-900">{request.sender.name}</p>
                                <p className="text-xs text-gray-500">
                                  Enrollment: {request.sender.enrollmentNo} • {request.sender.gender.charAt(0).toUpperCase() + request.sender.gender.slice(1)}
                                </p>
                              </div>
                              
                              <Badge className={`${
                                request.status === 'accepted' ? 'bg-green-100 text-green-700' :
                                request.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                'bg-blue-100 text-blue-700'
                              } border-0`}>
                                {request.status === 'accepted' ? 'Accepted' :
                                 request.status === 'rejected' ? 'Rejected' : 'Pending'}
                              </Badge>
                            </div>
                            
                            <div className="mt-2">
                              <p className="text-gray-800">{request.message}</p>
                              <div className="mt-1 flex items-center text-xs text-gray-500">
                                <span>Ride: {request.ride.from} → {request.ride.to}</span>
                                <span className="mx-2">•</span>
                                <span>{request.ride.date} at {request.ride.time}</span>
                              </div>
                            </div>
                            
                            <div className="mt-3 flex items-center justify-between">
                              <span className="text-xs text-gray-500">
                                {formatTimestamp(request.timestamp)}
                              </span>
                              
                              {request.status === 'pending' && (
                                <div className="flex space-x-2">
                                  <Button 
                                    variant="outline" 
                                    size="sm" 
                                    className="text-red-600 border-red-200 hover:bg-red-50"
                                    onClick={() => handleRejectRequest(request.id)}
                                  >
                                    <X className="h-4 w-4 mr-1" />
                                    Reject
                                  </Button>
                                  <Button 
                                    size="sm" 
                                    className="bg-eco-600 hover:bg-eco-700 text-white"
                                    onClick={() => handleAcceptRequest(request.id)}
                                  >
                                    <Check className="h-4 w-4 mr-1" />
                                    Accept
                                  </Button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title="No ride requests"
                  description="You don't have any ride requests at the moment."
                  icon={<MessageSquare className="h-8 w-8" />}
                  actionLabel="Create Ride Request"
                  actionLink="/request"
                />
              )}
            </TabsContent>
            
            <TabsContent value="notifications">
              {filteredNotifications.length > 0 ? (
                <div className="space-y-3">
                  {filteredNotifications.map((notification) => (
                    <div 
                      key={notification.id} 
                      className={`bg-white rounded-lg shadow-sm overflow-hidden border border-gray-100 p-4 transition-all ${
                        !notification.isRead ? 'bg-eco-50 border-l-4 border-l-eco-500' : ''
                      }`}
                    >
                      <div className="flex items-start">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          notification.type === 'success' ? 'bg-green-100 text-green-600' :
                          notification.type === 'error' ? 'bg-red-100 text-red-600' :
                          'bg-blue-100 text-blue-600'
                        }`}>
                          {notification.type === 'success' ? (
                            <Check className="h-5 w-5" />
                          ) : notification.type === 'error' ? (
                            <X className="h-5 w-5" />
                          ) : (
                            <Info className="h-5 w-5" />
                          )}
                        </div>
                        
                        <div className="ml-3 flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-gray-900">{notification.title}</p>
                            <span className="text-xs text-gray-500">
                              {formatTimestamp(notification.timestamp)}
                            </span>
                          </div>
                          
                          <p className="mt-1 text-gray-600">{notification.message}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState 
                  title="No notifications"
                  description="You don't have any notifications at the moment."
                  icon={<Info className="h-8 w-8" />}
                  actionLabel="Explore Rides"
                  actionLink="/browse"
                />
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Messages;
