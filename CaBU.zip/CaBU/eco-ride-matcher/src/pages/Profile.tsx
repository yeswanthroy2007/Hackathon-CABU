
import React, { useState } from 'react';
import { User, Edit, Mail, Phone, MapPin, LogOut, Bookmark, Settings } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from 'sonner';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

const Profile = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [user, setUser] = useState({
    name: 'Alex Johnson',
    enrollmentNo: 'EN2022034',
    email: 'alex.j@university.edu',
    phone: '+91 98765 43210',
    gender: 'male',
    department: 'Computer Science',
    year: '3rd Year',
    bio: 'Hello! I commute daily between North Campus and City Center. Looking for ride buddies to share costs and reduce emissions.',
    address: 'North Campus, Block C, Room 304'
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setIsEditing(false);
    toast.success("Profile updated successfully!");
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setUser(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
            {/* Profile Header */}
            <div className="bg-gradient-to-r from-eco-500 to-rider-500 h-32 sm:h-48 relative">
              <div className="absolute bottom-0 left-0 right-0 px-6 pb-3 pt-16 bg-gradient-to-t from-black/50 to-transparent">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="absolute top-4 right-4 bg-white/90 hover:bg-white"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                  {!isEditing && <Edit className="ml-2 h-4 w-4" />}
                </Button>
              </div>
            </div>
            
            <div className="px-6 pt-0 pb-6 sm:px-8 sm:pt-0 sm:pb-8 relative">
              <div className="flex flex-col sm:flex-row sm:items-end -mt-16 mb-6">
                <div className="h-24 w-24 sm:h-32 sm:w-32 rounded-full border-4 border-white bg-white shadow-md overflow-hidden">
                  <div className={`w-full h-full rounded-full flex items-center justify-center ${
                    user.gender === 'female' ? 'bg-pink-100 text-pink-600' : 'bg-blue-100 text-blue-600'
                  }`}>
                    <User className="h-16 w-16" />
                  </div>
                </div>
                
                <div className="mt-4 sm:ml-6 sm:mt-0">
                  <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                  <p className="text-gray-600">{user.department}, {user.year}</p>
                  <div className="flex items-center mt-1">
                    <span className="inline-block bg-eco-100 text-eco-800 text-xs px-2 py-1 rounded-full">
                      Enrollment: {user.enrollmentNo}
                    </span>
                    <span className="inline-block ml-2 bg-rider-100 text-rider-800 text-xs px-2 py-1 rounded-full">
                      {user.gender.charAt(0).toUpperCase() + user.gender.slice(1)}
                    </span>
                  </div>
                </div>
              </div>
              
              <Tabs defaultValue="profile">
                <TabsList className="mb-6">
                  <TabsTrigger value="profile">Profile</TabsTrigger>
                  <TabsTrigger value="preferences">Preferences</TabsTrigger>
                  <TabsTrigger value="saved">Saved Rides</TabsTrigger>
                </TabsList>
                
                <TabsContent value="profile">
                  {isEditing ? (
                    <form onSubmit={handleSaveProfile} className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-2">
                          <Label htmlFor="name">Full Name</Label>
                          <Input
                            id="name"
                            name="name"
                            value={user.name}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={user.email}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input
                            id="phone"
                            name="phone"
                            value={user.phone}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="department">Department</Label>
                          <Input
                            id="department"
                            name="department"
                            value={user.department}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="year">Year</Label>
                          <Input
                            id="year"
                            name="year"
                            value={user.year}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="address">Address</Label>
                          <Input
                            id="address"
                            name="address"
                            value={user.address}
                            onChange={handleInputChange}
                            required
                          />
                        </div>
                        
                        <div className="space-y-2 sm:col-span-2">
                          <Label htmlFor="bio">Bio</Label>
                          <Textarea
                            id="bio"
                            name="bio"
                            rows={4}
                            value={user.bio}
                            onChange={handleInputChange}
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-4">
                        <Button type="submit" className="bg-eco-600 hover:bg-eco-700 text-white">
                          Save Changes
                        </Button>
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={() => setIsEditing(false)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </form>
                  ) : (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <div>
                            <h3 className="text-sm font-medium text-gray-500">Contact Information</h3>
                            <div className="mt-2 space-y-2">
                              <div className="flex items-center">
                                <Mail className="h-4 w-4 text-gray-400 mr-2" />
                                <span className="text-gray-900">{user.email}</span>
                              </div>
                              <div className="flex items-center">
                                <Phone className="h-4 w-4 text-gray-400 mr-2" />
                                <span className="text-gray-900">{user.phone}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div>
                            <h3 className="text-sm font-medium text-gray-500">Address</h3>
                            <div className="mt-2 flex items-start">
                              <MapPin className="h-4 w-4 text-gray-400 mr-2 mt-0.5" />
                              <span className="text-gray-900">{user.address}</span>
                            </div>
                          </div>
                        </div>
                        
                        <div>
                          <h3 className="text-sm font-medium text-gray-500">About</h3>
                          <p className="mt-2 text-gray-900">{user.bio}</p>
                        </div>
                      </div>
                      
                      <div className="pt-4 border-t border-gray-200">
                        <h3 className="text-sm font-medium text-gray-500 mb-3">Account Settings</h3>
                        <div className="flex flex-wrap gap-3">
                          <Button variant="outline" className="text-gray-700">
                            <Settings className="h-4 w-4 mr-2" />
                            Account Settings
                          </Button>
                          <Button variant="outline" className="text-red-600 border-red-200 hover:bg-red-50">
                            <LogOut className="h-4 w-4 mr-2" />
                            Sign Out
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="preferences">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-gray-900 mb-4">Ride Preferences</h3>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div className="space-y-3">
                          <Label>Preferred Gender for Car Sharing</Label>
                          <div className="flex items-center space-x-4">
                            <Button variant="outline" className="border-eco-200 bg-eco-50 text-eco-700" disabled>
                              Any Gender
                            </Button>
                            <Button variant="outline">
                              Same Gender Only
                            </Button>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <Label>Common Routes</Label>
                          <div className="space-y-2">
                            <div className="flex justify-between items-center bg-gray-50 rounded-md p-2 border border-gray-200">
                              <span className="text-sm">North Campus → City Center</span>
                              <Button variant="ghost" size="sm" className="h-7 text-xs">
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                            </div>
                            <div className="flex justify-between items-center bg-gray-50 rounded-md p-2 border border-gray-200">
                              <span className="text-sm">University → Airport</span>
                              <Button variant="ghost" size="sm" className="h-7 text-xs">
                                <Edit className="h-3 w-3 mr-1" />
                                Edit
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-6">
                      <h3 className="text-lg font-medium text-gray-900 mb-4">Notification Preferences</h3>
                      
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-700">Email Notifications</span>
                          <input type="checkbox" className="toggle bg-gray-200" defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-gray-700">Push Notifications</span>
                          <input type="checkbox" className="toggle bg-gray-200" defaultChecked />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-gray-700">New Ride Alerts</span>
                          <input type="checkbox" className="toggle bg-gray-200" defaultChecked />
                        </div>
                      </div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="saved">
                  <div className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <div className="mx-auto h-16 w-16 rounded-full bg-gray-100 flex items-center justify-center mb-4">
                        <Bookmark className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-900 mb-1">No Saved Rides</h3>
                      <p className="text-gray-600 max-w-sm">
                        You haven't saved any rides yet. When you find a ride you like, 
                        tap the bookmark icon to save it for later.
                      </p>
                      <Button className="mt-4 bg-eco-600 hover:bg-eco-700 text-white">
                        Browse Rides
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Profile;
