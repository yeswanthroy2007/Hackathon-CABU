
import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Link } from 'react-router-dom';
import { Car, Calendar, Clock, Users, DollarSign } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from 'sonner';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

interface RequestFormData {
  from: string;
  to: string;
  date: string;
  time: string;
  seats: number;
  price: number;
  notes: string;
}

const RequestRide = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const { register, handleSubmit, formState: { errors }, reset } = useForm<RequestFormData>({
    defaultValues: {
      from: '',
      to: '',
      date: '',
      time: '',
      seats: 1,
      price: 50,
      notes: ''
    }
  });

  const popularDestinations = [
    "University Main Gate",
    "City Center Mall",
    "Railway Station",
    "Airport",
    "North Campus",
    "Library",
    "Sports Complex"
  ];

  const onSubmit = (data: RequestFormData) => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      console.log("Submitted data:", data);
      toast.success("Your ride request has been created!");
      reset();
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow py-8">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h1 className="text-2xl font-bold text-gray-900">Request a Ride</h1>
            <p className="text-gray-600 mt-2">
              Create a ride request to find other students traveling the same way
            </p>
          </div>
          
          <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="from">From</Label>
                  <Input
                    id="from"
                    placeholder="Pickup location"
                    {...register('from', { required: "Pickup location is required" })}
                    className={errors.from ? 'border-red-300' : ''}
                  />
                  {errors.from && (
                    <p className="text-sm text-red-500">{errors.from.message}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {popularDestinations.slice(0, 3).map((location) => (
                      <Button 
                        key={location}
                        type="button" 
                        variant="outline" 
                        size="sm"
                        className="text-xs bg-gray-50 border-gray-200 hover:bg-gray-100"
                        onClick={() => {
                          const fromInput = document.getElementById('from') as HTMLInputElement;
                          if (fromInput) fromInput.value = location;
                        }}
                      >
                        {location}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="to">To</Label>
                  <Input
                    id="to"
                    placeholder="Destination"
                    {...register('to', { required: "Destination is required" })}
                    className={errors.to ? 'border-red-300' : ''}
                  />
                  {errors.to && (
                    <p className="text-sm text-red-500">{errors.to.message}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {popularDestinations.slice(3, 6).map((location) => (
                      <Button 
                        key={location}
                        type="button" 
                        variant="outline" 
                        size="sm"
                        className="text-xs bg-gray-50 border-gray-200 hover:bg-gray-100"
                        onClick={() => {
                          const toInput = document.getElementById('to') as HTMLInputElement;
                          if (toInput) toInput.value = location;
                        }}
                      >
                        {location}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                    <Input
                      id="date"
                      type="date"
                      {...register('date', { required: "Date is required" })}
                      className={errors.date ? 'border-red-300' : ''}
                    />
                  </div>
                  {errors.date && (
                    <p className="text-sm text-red-500">{errors.date.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-gray-400 mr-2" />
                    <Input
                      id="time"
                      type="time"
                      {...register('time', { required: "Time is required" })}
                      className={errors.time ? 'border-red-300' : ''}
                    />
                  </div>
                  {errors.time && (
                    <p className="text-sm text-red-500">{errors.time.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="seats">Available Seats</Label>
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-gray-400 mr-2" />
                    <Input
                      id="seats"
                      type="number"
                      min="1"
                      max="10"
                      {...register('seats', { 
                        required: "Number of seats is required",
                        min: { value: 1, message: "At least 1 seat is required" },
                        max: { value: 10, message: "Maximum 10 seats allowed" }
                      })}
                      className={errors.seats ? 'border-red-300' : ''}
                    />
                  </div>
                  {errors.seats && (
                    <p className="text-sm text-red-500">{errors.seats.message}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="price">Price per person (₹)</Label>
                  <div className="flex items-center">
                    <DollarSign className="h-5 w-5 text-gray-400 mr-2" />
                    <Input
                      id="price"
                      type="number"
                      min="0"
                      step="10"
                      {...register('price', { 
                        required: "Price is required",
                        min: { value: 0, message: "Price cannot be negative" }
                      })}
                      className={errors.price ? 'border-red-300' : ''}
                    />
                  </div>
                  {errors.price && (
                    <p className="text-sm text-red-500">{errors.price.message}</p>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="notes">Additional Notes (Optional)</Label>
                <Textarea
                  id="notes"
                  placeholder="Any special instructions or details about the ride..."
                  {...register('notes')}
                  rows={3}
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <Button 
                  type="submit" 
                  className="bg-eco-600 hover:bg-eco-700 text-white"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? 'Creating Request...' : 'Create Ride Request'}
                  <Car className="ml-2 h-4 w-4" />
                </Button>
                
                <Link to="/browse">
                  <Button variant="outline" type="button">
                    Browse Existing Rides
                  </Button>
                </Link>
              </div>
            </form>
          </div>
          
          <div className="mt-8 bg-blue-50 rounded-lg p-4 border border-blue-100">
            <h3 className="font-medium text-blue-800 flex items-center">
              <Car className="h-5 w-5 mr-2" />
              Tips for a Successful Ride
            </h3>
            <ul className="mt-2 space-y-1 text-sm text-blue-700">
              <li>• Be specific about pickup and drop-off locations</li>
              <li>• Set a reasonable price based on distance</li>
              <li>• Create requests at least a few hours in advance</li>
              <li>• Check your messages for ride confirmations</li>
            </ul>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default RequestRide;
