
import React from 'react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { Car, Users, Smile, Award, Calendar, Flag } from 'lucide-react';

const AboutUs = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-eco-600 to-rider-600 py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
            <h1 className="text-4xl font-bold mb-4">About Cab U</h1>
            <p className="text-xl max-w-3xl mx-auto opacity-90">
              Created by students, for students - transforming campus transportation one ride at a time.
            </p>
          </div>
        </section>
        
        {/* Our Story Section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="lg:grid lg:grid-cols-2 lg:gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
                <p className="text-gray-600 mb-4">
                  Cab U was born from a simple observation: hundreds of students were traveling the same routes alone, all paying full fare for their rides, while others struggled to find affordable transportation options.
                </p>
                <p className="text-gray-600 mb-4">
                  Founded in 2023 by a group of engineering students, our platform started as a simple ride-sharing board that quickly grew into a comprehensive transportation solution for the entire campus community.
                </p>
                <p className="text-gray-600">
                  Today, Cab U serves thousands of students across campus, helping them save money, make connections, and get where they need to go safely and efficiently.
                </p>
              </div>
              <div className="mt-10 lg:mt-0">
                <img 
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" 
                  alt="Students working together" 
                  className="rounded-xl shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Our Mission Section */}
        <section className="py-16 bg-eco-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
            <p className="text-xl text-gray-700 max-w-4xl mx-auto mb-12">
              To make student transportation more affordable, accessible, and community-oriented by connecting students who are traveling the same way.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mx-auto mb-4">
                  <Smile className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Student Experience</h3>
                <p className="text-gray-600">
                  Creating a seamless, affordable, and safe transportation experience for every student on campus.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Community Building</h3>
                <p className="text-gray-600">
                  Fostering connections between students and creating a trusted community of riders.
                </p>
              </div>
              
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center mx-auto mb-4">
                  <Car className="h-6 w-6 text-eco-600" />
                </div>
                <h3 className="text-xl font-medium text-gray-900 mb-2">Resource Efficiency</h3>
                <p className="text-gray-600">
                  Maximizing the use of existing transportation and reducing the number of half-empty vehicles on the road.
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Milestones */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Our Journey</h2>
            
            <div className="space-y-12">
              <div className="flex flex-col md:flex-row items-start">
                <div className="flex-shrink-0 flex flex-col items-center mr-6">
                  <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center">
                    <Flag className="h-6 w-6 text-eco-600" />
                  </div>
                  <div className="h-full w-0.5 bg-eco-100 mt-4 hidden md:block"></div>
                </div>
                <div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium text-eco-600">September 2023</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-900 mt-1 mb-2">The Idea Takes Shape</h3>
                  <p className="text-gray-600">
                    Four engineering students recognized the transportation challenges on campus and began developing the first prototype of what would become Cab U.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start">
                <div className="flex-shrink-0 flex flex-col items-center mr-6">
                  <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center">
                    <Flag className="h-6 w-6 text-eco-600" />
                  </div>
                  <div className="h-full w-0.5 bg-eco-100 mt-4 hidden md:block"></div>
                </div>
                <div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium text-eco-600">January 2024</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-900 mt-1 mb-2">Official Launch</h3>
                  <p className="text-gray-600">
                    After months of development and testing, Cab U launched officially, welcoming our first 100 users from the Engineering and Computer Science departments.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start">
                <div className="flex-shrink-0 flex flex-col items-center mr-6">
                  <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center">
                    <Flag className="h-6 w-6 text-eco-600" />
                  </div>
                  <div className="h-full w-0.5 bg-eco-100 mt-4 hidden md:block"></div>
                </div>
                <div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium text-eco-600">March 2024</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-900 mt-1 mb-2">Campus-wide Expansion</h3>
                  <p className="text-gray-600">
                    With growing demand, we expanded to serve all departments across campus, reaching over 500 active users and facilitating more than 1,000 rides.
                  </p>
                </div>
              </div>
              
              <div className="flex flex-col md:flex-row items-start">
                <div className="flex-shrink-0 flex flex-col items-center mr-6">
                  <div className="h-12 w-12 rounded-full bg-eco-100 flex items-center justify-center">
                    <Award className="h-6 w-6 text-eco-600" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 text-eco-600 mr-2" />
                    <span className="text-sm font-medium text-eco-600">Present</span>
                  </div>
                  <h3 className="text-xl font-medium text-gray-900 mt-1 mb-2">Growing Strong</h3>
                  <p className="text-gray-600">
                    Today, Cab U has become an essential part of campus life, with over 1,200 active users, thousands of rides shared, and millions of rupees saved by students on transportation costs.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA Section */}
        <section className="py-16 bg-eco-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">Join Our Team</h2>
            <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-8">
              Are you passionate about improving campus life? We're always looking for talented students to join our team.
            </p>
            <button className="bg-eco-600 text-white px-6 py-3 rounded-md font-medium hover:bg-eco-700 transition-colors">
              View Open Positions
            </button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default AboutUs;
