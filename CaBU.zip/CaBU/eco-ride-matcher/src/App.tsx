
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import RequestRide from "./pages/RequestRide";
import BrowseRides from "./pages/BrowseRides";
import Profile from "./pages/Profile";
import RideHistory from "./pages/RideHistory";
import Messages from "./pages/Messages";
import NotFound from "./pages/NotFound";
import FAQ from "./pages/FAQ";
import Safety from "./pages/Safety";
import Testimonials from "./pages/Testimonials";
import AboutUs from "./pages/AboutUs";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/request" element={<RequestRide />} />
          <Route path="/browse" element={<BrowseRides />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/history" element={<RideHistory />} />
          <Route path="/messages" element={<Messages />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/safety" element={<Safety />} />
          <Route path="/testimonials" element={<Testimonials />} />
          <Route path="/about" element={<AboutUs />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
